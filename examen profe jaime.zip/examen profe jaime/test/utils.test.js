import Utils  from "../src/utils.js";
import { expect } from 'chai';

const utils = new Utils();

describe('Clase Utils', () => {
    describe('square()', () => {
        it('Debe devolver el cuadrado de un número positivo', () => {
            expect(utils.square(3)).to.equal(9);
        });

        it('Debe devolver el cuadrado de un número negativo', () => {
            expect(utils.square(-4)).to.equal(16);
        });
    });

    describe('isOdd()', () => {
        it('Debe devolver verdadero si el número es impar', () => {
            expect(utils.isOdd(5)).to.be.true;
        });

        it('Debe devolver falso si el número es par', () => {
            expect(utils.isOdd(4)).to.be.false;
        });
    });

    describe('getMin()', () => {
        it('Debe devolver el número mínimo de un arreglo', () => {
            expect(utils.getMin([3, 1, 2])).to.equal(1);
        });

        it('Debe lanzar un error si el arreglo está vacío', () => {
            expect(() => utils.getMin([])).to.throw('Array vacío no permitido');
        });
    });

    describe('toCamelCase()', () => {
        it('Debe convertir una cadena con guiones a formato Camel Case', () => {
            expect(utils.toCamelCase('hola-mundo')).to.equal('holaMundo');
        });

        it('Debe manejar cadenas con múltiples guiones', () => {
            expect(utils.toCamelCase('convertir-esta-cadena')).to.equal('convertirEstaCadena');
        });
    });

    describe('filterOdds()', () => {
        it('Debe devolver solo los números impares de un arreglo', () => {
            expect(utils.filterOdds([1, 2, 3, 4])).to.eql([1, 3]);
        });

        it('Debe devolver un arreglo vacío si no hay números impares', () => {
            expect(utils.filterOdds([2, 4, 6])).to.eql([]);
        });
    });
});
