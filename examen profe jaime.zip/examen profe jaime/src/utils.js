export default class Utils {
    square(num) {
        return num * num;
    }

    isOdd(num) {
        return num % 2 !== 0;
    }

    getMin(array) {
        if (array.length === 0) {
            throw new Error('Array vacío no permitido');
        }
        return Math.min(...array);
    }

    toCamelCase(str) {
        return str
            .split('-')
            .map((word, index) =>
                index === 0 ? word : word.charAt(0).toUpperCase() + word.slice(1)
            )
            .join('');
    }

    filterOdds(array) {
        return array.filter(num => num % 2 !== 0);
    }
}
